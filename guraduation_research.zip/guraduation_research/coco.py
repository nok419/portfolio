#Microsoftが提供するcocoデータセットから、任意の画像をランダムに抽出するためのツールです
from pycocotools.coco import COCO
import numpy as np
import matplotlib.pyplot as plt
from skimage import io,img_as_float, img_as_uint, img_as_ubyte
dataDir =''
dataType='val2014'
annFile='%sannotations/instances_%s.json'%(dataDir,dataType)

# initialize COCO api for instance annotations
coco=COCO(annFile)
# display COCO categories and supercategories
cats = coco.loadCats(coco.getCatIds())
nms=[cat['name'] for cat in cats]
print ('COCO categories: \n\n', ' '.join(nms))

nms = set([cat['supercategory'] for cat in cats])
print( 'COCO supercategories: \n', ' '.join(nms))
catIds = coco.getCatIds(catNms=['train'])#得たい画像のキーワードを入力
imgIds = coco.getImgIds(catIds=catIds )
img = coco.loadImgs(imgIds[np.random.randint(0,len(imgIds))])[0]

I = io.imread('val2014/%s/%s'%(dataType,img['file_name']))
plt.figure()
plt.imshow(I)
plt.show()